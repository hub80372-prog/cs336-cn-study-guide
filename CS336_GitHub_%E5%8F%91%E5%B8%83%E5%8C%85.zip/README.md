# CS336：从零构建大语言模型（中文学习资料）

本项目包含一份中文长篇学习资料，主题涵盖 tokenizer、Transformer、GPU 系统优化、分布式训练、推理加速、Scaling Laws、数据工程等。

## 阅读

- [完整 Markdown 教程](CS336_完整教程.md)
- [PDF 电子版](CS336_完整教程.pdf)

## 说明

资料根据提供的原始文本整理，保留原有论述。**并非斯坦福大学官方授权教材或官方课程译本**。原文中的部分公式包含从复制/粘贴产生的排版问题；关键技术论断、数值与引用均未逐项核验，学习及引用时请与课程和原始论文核对。

课程参考：[Stanford CS336](https://stanford-cs336.github.io/spring2025/)。

## 发布

可以直接通过 GitHub 网页创建仓库并上传项目中的文件；也可以使用 Git：

```bash
git init
git add .
git commit -m "Add CS336 Chinese study guide and PDF"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/cs336-cn-study-guide.git
git push -u origin main
```

请将 `YOUR_USERNAME` 换成自己的 GitHub 用户名，并先在 GitHub 创建空仓库。

## 授权

尚未指定再发布许可。请在确认原始文本的版权和许可情况后添加 LICENSE 文件。
